<?php
/*
Plugin Name: symbol custom post slider
Plugin URI: http://hellothirteen.com/
Description: Declares a plugin that will create a custom post type displaying slider.
Version: 1.0
Author: aarif hassan
Author URI: http://design.hellothirteen.com
License: GPLv2
*/


// post type for mian slider   

function symbol_custom_post_slider() {
        $labels = array(
                'name'               => __( 'Slider', 'symbol' ),
                'singular_name'      => __( 'Slider', 'symbol' ),
                'add_new'            => __( 'Add New', 'symbol' ),
                'add_new_item'       => __( 'Add New Slider', 'symbol' ),
                'edit_item'          => __( 'Edit Slider', 'symbol' ),
                'new_item'           => __( 'New Slider', 'symbol' ),
                'all_items'          => __( 'All Slider', 'symbol' ),
                'view_item'          => __( 'View Slider', 'symbol' ),
                'search_items'       => __( 'Search Slider', 'symbol' ),
                'not_found'          => __( 'No Slider found', 'symbol' ),
                'not_found_in_trash' => __( 'No Slider found in the Trash', 'symbol' ),
                'parent_item_colon'  => '',
                'menu_name'          => 'Slider'
        );
        $args = array(
                'labels'        => $labels,
                'description'   => __( 'symbol sliders are here', 'symbol' ),
                'public'        => true,
                'menu_position' => 5,
                'menu_icon'     => 'dashicons-images-alt2',
                'supports'      => array( 'title', 'editor', 'thumbnail'),
                'has_archive'   => true,
        );
        register_post_type( 'symbol_main_slider', $args );
}
add_action( 'init', 'symbol_custom_post_slider' );